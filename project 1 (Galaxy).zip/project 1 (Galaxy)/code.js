var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["85f9772c-dc57-4581-b84e-f8ecea2fd28a","913a46bd-ec20-4c13-be71-e997d7770227"],"propsByKey":{"85f9772c-dc57-4581-b84e-f8ecea2fd28a":{"name":"rocket1_1","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"Z3sbUX_c8Rb9_bVzKpX1Pd1oZJFWOdNB","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/85f9772c-dc57-4581-b84e-f8ecea2fd28a.png"},"913a46bd-ec20-4c13-be71-e997d7770227":{"name":"space_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var scene = createSprite(200,200);
scene.setAnimation("space_1");

var rocket1 = createSprite(200,350);
rocket1.setAnimation("rocket1_1");
rocket1.scale = 0.25;
rocket1.velocityY = -5;

var rocket2 = createSprite(50,350);
rocket2.setAnimation("rocket1_1");
rocket2.rotation = 45;
rocket2.scale = 0.25;
rocket2.velocityY = -5;
rocket2.velocityX = 5;

var rocket3 = createSprite(350,350);
rocket3.setAnimation("rocket1_1");
rocket3.rotation = -45;
rocket3.scale = 0.25;
rocket3.velocityY = -5;
rocket3.velocityX = -5;

function draw() {

  rocket1.velocityY = rocket1.velocityY +0.03;
  rocket1.scale = rocket1.scale - 0.001;
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
